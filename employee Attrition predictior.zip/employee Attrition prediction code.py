import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score , confusion_matrix , f1_score , precision_score,recall_score
from xgboost import XGBClassifier

df=pd.read_csv("employee Attrition predictior daraset.csv",encoding="latin - 1")
print("\n")
print("XGboost algorithm \n")
print("\n")
print(df.head())
num_cols=df.select_dtypes(include=np.number).columns
df[num_cols] = df[num_cols].fillna(df[num_cols].median())

cat_cols = df.select_dtypes(include="object").columns
df[cat_cols] = df[cat_cols].fillna(df[cat_cols].mode().iloc[0])

le = LabelEncoder()
df["Attrition"] = le.fit_transform(df["Attrition"]) 
X = df.drop("Attrition", axis=1)   
y = df["Attrition"] 

for col in X.select_dtypes(include="object").columns:
    le = LabelEncoder()
    X[col] = le.fit_transform(X[col])    
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=42,
    stratify=y
)
print("Test and train the model successfully")

xgb_model = XGBClassifier(
    n_estimators=300,
    learning_rate=0.05,
    max_depth=6,
    subsample=0.8,
    colsample_bytree=0.8,
    eval_metric="logloss",
    random_state=42
)
xgb_model.fit(X_train, y_train)
y_pred = xgb_model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Precision",precision_score(y_test,y_pred))
recall = recall_score(y_test, y_pred)
print("Recall Score:", recall)
print("F1 Score:", f1_score(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))


from sklearn.svm import SVC
print("\n")
print("Support vector machine algorithm\n")

svm_model = SVC(
    kernel="rbf",        
    C=1.0,
    gamma="scale",
    class_weight="balanced",  
    random_state=42
)

svm_model.fit(X_train, y_train)
y_pred = svm_model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred))
print("Recall Score:", recall_score(y_test, y_pred))
print("F1 Score:", f1_score(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))


from sklearn.ensemble import RandomForestClassifier

print("\n")
print("Random forest classifier algorithm \n")
rf_model = RandomForestClassifier(
    n_estimators=200,
    max_depth=10,
    random_state=42
)


rf_model.fit(X_train, y_train)
y_pred = rf_model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred))
print("Recall Score:", recall_score(y_test, y_pred))
print("F1 Score:", f1_score(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))


from sklearn.naive_bayes import GaussianNB
print("\n")
print("Navie bayes algroithm \n")

nb_model = GaussianNB()
nb_model.fit(X_train, y_train)

y_pred = nb_model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred))
print("Recall Score:", recall_score(y_test, y_pred))
print("F1 Score:", f1_score(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))


